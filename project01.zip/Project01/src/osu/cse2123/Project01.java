/*
 * Project01
 * This program takes in a text file with different types of media and books and then outputs the
 * most/least expensive one as well as output the one with the most and least amount of products
 * 
 * @author Tyler Zysberg
 * @version 20160907
 */

package osu.cse2123;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Project01 {

	public static void main(String[] args) {
		ArrayList Titles = new ArrayList();
		ArrayList Type  = new ArrayList();
		ArrayList Price = new ArrayList();
		ArrayList Quantity = new ArrayList();
		ArrayList TotalCost = new ArrayList();
		
		Scanner in = new Scanner(System.in);
		String data = getFile(in);
		int count = 0;
		
		try{
		File TextFile = new File(data);
		Scanner inputFile = new Scanner(TextFile);
		System.out.println();
		System.out.println("Product Summary Report");
		System.out.println("------------------------------------------------------------");
		
		while(inputFile.hasNext()){

		getTitle(Titles, inputFile.nextLine());

		getQuantity(Quantity, inputFile.nextInt());

		getPrice(Price, inputFile.nextDouble());

		getType(Type, inputFile.next());

		System.out.println("Title: " + Titles.get(count));

		System.out.println(" Product Type: " + Type.get(count));

		System.out.println(" Price: " + Price.get(count));

		System.out.println(" Quantity: " + Quantity.get(count));

		System.out.println();
		
		count++;
		
		if(inputFile.hasNextLine())
		{
		   inputFile.nextLine();
		}
		   else{
		}
	}
		
		System.out.println("------------------------------------------------------------");
		System.out.println("Total products in database: " + count);
		 
		for(int i = 0; i < count; i++){
			double price =(Double)(Price.get(i)) * (Integer)(Quantity.get(i));
			TotalCost.add(i,price); 
		}
		
		int largestItem = Quantity.indexOf(Collections.max(Quantity));
		String largeItem = (String) Titles.get(largestItem);
		String largeType = (String) Type.get(largestItem);
		
		int smallestItem = Quantity.indexOf(Collections.min(Quantity));
		String smallItem = (String) Titles.get(smallestItem);
		String smallType = (String) Type.get(smallestItem);
		
		int largePrice = TotalCost.indexOf(Collections.max(TotalCost));
		String LargestPriceItem = (String)Titles.get(largePrice);
		double price01 = (Double)TotalCost.get(largePrice);
		
		int SmallPrice = TotalCost.indexOf(Collections.min(TotalCost));
		String SmallestPriceItem = (String)Titles.get(SmallPrice);
		double price02 = (Double)TotalCost.get(SmallPrice);
		 
		System.out.println("Largest quantity item: " + largeItem + "(" + largeType + ")");
		System.out.println("Highest total dollar item: " + LargestPriceItem + " ($" + price01 + ")");
		System.out.println("Smallest quantity item: " + smallItem + "(" + smallType + ")");
		System.out.println("Lowest total dollar item: " + SmallestPriceItem + " ($" + price02 + ")");
		
		System.out.println("------------------------------------------------------------");
		inputFile.close();

	}
		catch(IOException e)
		{
			System.out.println("Error reading file from " + data);
		}
		
			in.close();
	}
	private static String getFile(Scanner name){
		System.out.print("Enter database filename:");
		String File = name.nextLine();
		return File;
	}
	
	private static void getTitle(ArrayList Title, String title){
		Title.add(title);
	}
	
	private static void getType(ArrayList Type, String type){
		Type.add(type);
	}
	
	private static void getPrice(ArrayList Price, double price){
		Price.add(price);
	}
	
	private static void getQuantity(ArrayList Quantity, int quantity){
		Quantity.add(quantity);
	
	}
	
}
